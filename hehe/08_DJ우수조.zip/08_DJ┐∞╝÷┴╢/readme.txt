ray_mpi.py = 병렬 코드
parameters : 
width = 300
height = 200
camera = np.array([0, 0, 1])
light = { 'position': np.array([5, 5, 5]), 'ambient': np.array([1, 1, 1]), 'diffuse': np.array([1, 1, 1]), 'specular': np.array([1, 1, 1]) }
objects = [
    { 'center': np.array([-0.2, 0, -1]), 'radius': 0.2, 'ambient': np.array([0.1, 0, 0]), 'diffuse': np.array([0.7, 1, 0]), 'specular': np.array([1, 1, 1]), 'shininess': 80, 'reflection': 0.1 },
    { 'center': np.array([0.1, -0.3, 0]), 'radius': 0.1, 'ambient': np.array([0.1, 0, 0.1]), 'diffuse': np.array([0.7, 0, 0.7]), 'specular': np.array([1, 1, 1]), 'shininess': 100, 'reflection': 0.5 },
    { 'center': np.array([0.5, 0, -1]), 'radius': 0.5, 'ambient': np.array([0.1, 0, 0.1]), 'diffuse': np.array([0.7, 0.7, 0.7]), 'specular': np.array([1, 1, 1]), 'shininess': 100, 'reflection': 0.5 },
    { 'center': np.array([-0.3, 0, 0]), 'radius': 0.15, 'ambient': np.array([0, 0.1, 0]), 'diffuse': np.array([0, 0.6, 0]), 'specular': np.array([1, 1, 1]), 'shininess': 100, 'reflection': 0.5 },
    { 'center': np.array([0, -9000, 0]), 'radius': 9000 - 0.7, 'ambient': np.array([0.1, 0.1, 0.1]), 'diffuse': np.array([0.6, 0.6, 0.6]), 'specular': np.array([1, 1, 1]), 'shininess': 100, 'reflection': 0.5 }
]
design_ray_mpi = 디자인 코드
parameters : 
width = 300
height = 200
camera = camera_position
ambient_R = 0.7
diffuse_R = 1
specular_R= 0.5
light = { 'position': np.array([5, 5, 5]), 'ambient': np.array([1, 1, 1]), 'diffuse': np.array([1, 1, 1]), 'specular': np.array([1, 1, 1]) }
objects = [
    { 'center': np.array([-0.5, 0, 0]), 'radius': 0.2, 'ambient': np.array([0.9 * ambient_R , 0.243 * ambient_R , 0.463 * ambient_R]), 'diffuse': np.array([1.0 * diffuse_R , 0.4 * diffuse_R , 0.0 * diffuse_R]), 'specular': np.array([1 * specular_R , 1 * specular_R , 1 * specular_R ]), 'shininess': 50, 'reflection': 0.5 },
    { 'center': np.array([0, 0, 0]), 'radius': 0.2, 'ambient': np.array([0.082 * ambient_R , 0.502 * ambient_R ,0.0 * ambient_R]), 'diffuse': np.array([1.0 * diffuse_R , 0.549 * diffuse_R , 0.0 * diffuse_R]), 'specular': np.array([1 * specular_R , 1 * specular_R , 1 * specular_R ]), 'shininess': 50, 'reflection': 0.5 },
    { 'center': np.array([0.5, 0, 0]), 'radius': 0.2, 'ambient': np.array([0.4 * ambient_R , 0.620 * ambient_R , 1.0 * ambient_R]), 'diffuse': np.array([0.0 * diffuse_R , 1.0 * diffuse_R , 0.635 * diffuse_R]), 'specular': np.array([1 * specular_R , 1 * specular_R , 1 * specular_R ]), 'shininess': 50, 'reflection': 0.5 },
    { 'center': np.array([0, -9000, 0]), 'radius': 9000 - 0.7, 'ambient': np.array([0.1, 0.1, 0.1]), 'diffuse': np.array([0.5, 0.5, 0.5]), 'specular': np.array([1, 1, 1]), 'shininess': 100, 'reflection': 0.5 }
]
Img_generate = 이미지 만드는 코드
Gif_generate = gif 만드는 코드
animated.gif = 동영상