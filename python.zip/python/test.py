import sys, getopt

x, y = -1.3, 0
w, h = 512, 512
scale = 0.075
maxit = 500
filename = "img1.bmp"

def main(argv):
	global x, y 
	global w, h 
	global scale 
	global maxit 
	global filename
	try: 
		opts, args = getopt.getopt(argv,"x:y:s:W:H:m:o:h") 
	except getopt.GetoptError:
		print ('mandel.py -x xcenter -y ycenter -s scale -W width -H height -m maxit -o filename')
		sys.exit(2) 
	for opt, arg in opts: 
		if opt == '-h': 
			print ('mandel.py -x xcenter -y ycenter -s scale -W width -H height -m maxit -o filename')
			sys.exit() 
		elif opt in ("-x"): 
			x = arg 
		elif opt in ("-y"): 
			y = arg 
		elif opt in ("-s"):
			scale = arg
		elif opt in ("-W"):
			w = arg
		elif opt in ("-H"):
			h = arg
		elif opt in ("-m"):
			maxit = arg
		elif opt in ("-o"):
			filename = arg

main(sys.argv[1:])
print ("mandel: x=", x, "y=", y, "scale=", scale, "maxit=", maxit, "output=", filename)
