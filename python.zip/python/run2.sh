#!/bin/bash
#PBS -N test
#PBS -V
#PBS -q youth
#PBS -A inhouse
#PBS -l select=1:ncpus=2:mpiprocs=2:ompthreads=1
#PBS -l walltime=00:30:00
#PBS -M abc@abc.com
#PBS -m abe

cd $PBS_O_WORKDIR
module purge
module add craype-network-opa
module add singularity/3.6.4
module add intel/18.0.3 impi/18.0.3
source ~/.bashrc

mpirun singularity exec ./my.sif python3 ./ray_mpi.py
